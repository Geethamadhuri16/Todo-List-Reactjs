package com.BlackCoffer.Visualization;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VisualizationApplicationTests {

	@Test
	void contextLoads() {
	}

}
